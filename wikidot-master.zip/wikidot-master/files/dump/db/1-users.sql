INSERT INTO ozone_user VALUES (-1, 'Automatic', 'Automatic', NULL, 'automatic@wikidot', 'automatic', NULL, NULL, false, false, 'en');;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
INSERT INTO ozone_user VALUES (0, 'Anonymous', 'Anonymous', NULL, 'anonymous@wikidot', 'anonymous', NULL, NULL, false, false, 'en');;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
INSERT INTO ozone_user VALUES (1, 'Admin', 'Admin', 'a0987642602a842d8f325a7d1bbb7fdb', '', 'admin', '2009-02-05 23:52:51', NULL, true, false, 'en');;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

