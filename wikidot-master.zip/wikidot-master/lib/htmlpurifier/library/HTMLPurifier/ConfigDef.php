<?php

/**
 * Base class for configuration entity
 */
class HTMLPurifier_ConfigDef {
    public $class = false;
}

