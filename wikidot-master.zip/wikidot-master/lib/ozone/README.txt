OZONE Framework for Wikidot is a modified and adapted version
on the OZONE Web Application Framework, created originally by
Michal Frackowiak.

Original OZONE Framework has been hosted at
http://ozoneframework.sourceforge.net

Although there are many features not used by Wikidot please treat
this framework as an integral part of Wikidot.
